
  
<p align="center" width="100%">
<img width="15%" src="https://www.dropbox.com/scl/fi/qg2ej2vyx0tgaerrcpoel/topSpeen.webp?rlkey=m51zat9dg2s3bczbllr78ti8q&st=0r7hsbh1&dl=1">
    <img width="50%" src="https://www.dropbox.com/scl/fi/xi5i3gfp8m5johqw5j390/bigSpeen.webp?rlkey=5na45jd5zc5480z9uxwuoinv8&st=ma60ab1b&dl=1">
<img width="15%" src="https://www.dropbox.com/scl/fi/qg2ej2vyx0tgaerrcpoel/topSpeen.webp?rlkey=m51zat9dg2s3bczbllr78ti8q&st=0r7hsbh1&dl=1">
</p>


<p align="center" width="100%">
<a href="https://discord.gg/pZFR4sES"><img width="5%" src="https://www.dropbox.com/scl/fi/96uoyd529gq617880m0cu/636e0a6a49cf127bf92de1e2_icon_clyde_blurple_RGB.png?rlkey=343xgtya1h3r53bblx8lns473&st=ih0q2alh&dl=1"></a>
</p>

##

<p align="center"><img width="50%" src="https://www.dropbox.com/scl/fi/r71r794l58t66bnahwd01/spinnychairslogo.png?rlkey=exp7sr76l1pz0nelye2czjkut&st=g5tf25d3&dl=1"></p>

<p align="center">Enhance your report gathering duties with an all new, enhanced, Dr Bao endorsed SpinnyChair! </p>

##

This mod replaces the default console / computer chair in the base with a chair that spins. Pretty self explanatory.
   - Use A and D keys to rotate
   - Shift to increase rotational speed
   - Spacebar to "push" with legs to move around

  
<sub>Not actually trademarked</sub>