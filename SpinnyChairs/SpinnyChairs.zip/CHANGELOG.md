
# 1.0.2
 - Made Spinny Chair a proper prop
 - As a prop, chair can now be hooked properly (still not recommended to hook and pull while sitting in the chair)
 - As a prop, chair can now be saved and loaded, keeping positions
 - Now purchasable in the store
 - New sit action option, removing requirement to look at a large sitBox

# 1.0.1

 - Made the SpinnyChair spawn in the same location every time, fixing missing chair issue 
 - Added Uninstall mod to description

# 1.0.0

 - Initial Release