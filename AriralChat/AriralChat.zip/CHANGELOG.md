# 1.1.1
    - Various fixes, update is mandatory 

# 1.1.0
    - Added reply functionality to chat messages (mouse over a message)
    - Added highlights for @s
    - Added ability to send in-game photos taken with camera
    - Added ability to press enter to send chats
    - Users will now be able to reconnect from the same session instead of getting locked out of a name
    - Added changelog

# 1.0.0

- Initial Release