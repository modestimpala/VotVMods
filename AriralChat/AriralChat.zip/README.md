
![AriralChat](https://www.dropbox.com/scl/fi/aun8in2cvotefbzq5a1zo/ezgif.com-webp-maker.webp?rlkey=080x8atpe65u3tvlx3wif7nkz&st=x26zzei4&dl=1)

# AriralChat: In-Game IRC-Style Chat

Access a retro IRC-style chat through the in-game computer. Chat with in-game players in real-time, send photos, and converse in retro style.

Features:

 - Unique usernames with color-coding
 - Real-time messaging
 - Ability to send in-game photos
 - @ people by clicking on arrow next to their message
 - User list
 - Message history
 - Profanity filter
 - Moderation

To join, simply enter a username and start chatting!