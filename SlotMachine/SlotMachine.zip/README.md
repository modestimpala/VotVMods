
  
<p align="center" width="100%">
    <img width="20%" src="https://www.dropbox.com/scl/fi/lxm2y7oy8b5l9hrr9hxi5/2024-09-2718-42-28-ezgif.com-resize.webp?rlkey=nt7kq3qkz6v6jfx97lqkic71v&st=ytcmw9xy&dl=1">
</p>


<p align="center" width="100%">
<a href="https://discord.gg/pZFR4sES"><img width="5%" src="https://www.dropbox.com/scl/fi/96uoyd529gq617880m0cu/636e0a6a49cf127bf92de1e2_icon_clyde_blurple_RGB.png?rlkey=343xgtya1h3r53bblx8lns473&st=ih0q2alh&dl=1"></a>
</p>

##

<p align="center"><img width="50%" src="https://www.dropbox.com/scl/fi/sm12201qvl997rqrs2cop/gamblinglogo.png?rlkey=ik41lfxzyx1di6ei78uu2gw8l&st=lnedpw64&dl=1"></p>

<p align="center">Kill time and earn points with a fully functioning Slot Machine! Decorate your employee quaters with several Slot Machines to show just how dedicated you are to gambling! Chase the entrepreneur mindset!</p>

##

This mod adds an entire fully functional Slot Machine to the Store for purchase.

Features:
 - Multiple different payouts
 - Bonus, free spin and wildcard symbols
 - Articulating spin lever
 - Funny Mode (find the funny button)

Current Limitations: 
 - Shop order arrives as a cube, not sure why, since I'm creating it exactly like my SpinnyChairs mod
 - Points deposited are not saved in between sessions, be sure to cash out when done
 
Art including model, textures, and symbols are subject to change - I think it's fine for now but I'm not completely happy with it.

 Paytable:

 <img width="50%" src="https://www.dropbox.com/scl/fi/8hjuae6nlfqoeu4jrfout/paytable.png?rlkey=3k0eyyw14k817st0xfnr4cdle&st=oz037l26&dl=1">


